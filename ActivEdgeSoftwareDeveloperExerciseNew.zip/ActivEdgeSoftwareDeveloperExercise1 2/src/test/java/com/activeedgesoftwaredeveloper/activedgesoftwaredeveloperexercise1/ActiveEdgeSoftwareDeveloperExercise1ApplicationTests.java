package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActiveEdgeSoftwareDeveloperExercise1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
