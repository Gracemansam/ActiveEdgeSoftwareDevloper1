package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.controller;

import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto.NewPriceDto;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto.NewStockDto;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.model.Stock;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.service.StockService;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.utils.APIResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;

public class StockControllerTest {

    @Mock
    private StockService stockService;

    @InjectMocks
    private StockController stockController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllStocks() {
        // Arrange
        List<Stock> expectedStocks = new ArrayList<>();
        when(stockService.getAllStock()).thenReturn(expectedStocks);

        // Act
        List<Stock> actualStocks = stockController.getAllStocks();

        // Assert
        verify(stockService, times(1)).getAllStock();
        assertEquals(expectedStocks, actualStocks);
    }

    @Test
    public void testGetStockById() {
        // Arrange
        Long id = 1L;
        Stock stock = new Stock();
        when(stockService.getById(id)).thenReturn(ResponseEntity.ok().body(new APIResponse("Success", true,stock)));

        // Act
        ResponseEntity<APIResponse> response = stockController.getStockById(id);

        // Assert
        verify(stockService, times(1)).getById(id);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(stock, response.getBody());
    }

    @Test
    public void testUpdateStockPrice() {
        // Arrange
        Long id = 1L;
        NewPriceDto newPriceDto = new NewPriceDto();
        when(stockService.updatePrice(id, newPriceDto)).thenReturn(ResponseEntity.ok().body(new APIResponse("Success", true,newPriceDto)));

        // Act
        ResponseEntity<APIResponse> response = stockController.updateStockPrice(id, newPriceDto);

        // Assert
        verify(stockService, times(1)).updatePrice(id, newPriceDto);
        assertEquals(HttpStatus.OK, response.getStatusCode());
      //  assertNull(response.getBody().getData());
    }

    @Test
    public void testCreateStock() {
        // Arrange
        NewStockDto newStockDto = new NewStockDto();
        when(stockService.createStock(newStockDto)).thenReturn(ResponseEntity.ok().body(new APIResponse( "Success", true,newStockDto)));

        // Act
        ResponseEntity<APIResponse> response = stockController.createStock(newStockDto);

        // Assert
        verify(stockService, times(1)).createStock(newStockDto);
        assertEquals(HttpStatus.OK, response.getStatusCode());
       // assertNull(response.getBody().getData());
    }
}
