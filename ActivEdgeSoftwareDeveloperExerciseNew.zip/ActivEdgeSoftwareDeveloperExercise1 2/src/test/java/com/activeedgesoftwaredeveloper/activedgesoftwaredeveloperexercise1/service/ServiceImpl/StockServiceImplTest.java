package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.service.ServiceImpl;

import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto.NewPriceDto;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto.NewStockDto;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Exception.StockNotFoundException;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.model.Stock;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.repository.StockRepository;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.service.StockService;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.utils.APIResponse;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.utils.Responder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class StockServiceImplTest {

    @InjectMocks
    private StockService stockService;

    @Mock
    private StockRepository stockRepository;

    @Mock
    private Responder responder;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllStock() {
        // Mocking the repository behavior
        when(stockRepository.findAll()).thenReturn(List.of(new Stock(), new Stock()));

        // Calling the method to be tested
        List<Stock> stocks = stockService.getAllStock();

        // Verifying the repository interactions
        verify(stockRepository, times(1)).findAll();

        // Asserting the response
        assert stocks.size() == 2;
    }

    @Test
    public void testGetById() {
        // Mocking the input data
        Long id = 1L;

        // Mocking the repository behavior
        when(stockRepository.findById(id)).thenReturn(Optional.of(new Stock()));

        // Mocking the responder behavior
        when(responder.Okay(any())).thenReturn(ResponseEntity.ok().build());

        // Calling the method to be tested
        ResponseEntity<APIResponse> response = stockService.getById(id);

        // Verifying the repository interactions
        verify(stockRepository, times(1)).findById(id);

        // Verifying the responder interactions
        verify(responder, times(1)).Okay(any());

        // Asserting the response
        assert response.getStatusCode() == HttpStatus.OK;
    }

    @Test
    public void testGetByIdNotFound() {
        // Mocking the input data
        Long id = 1L;

        // Mocking the repository behavior
        when(stockRepository.findById(id)).thenReturn(Optional.empty());

        // Mocking the responder behavior
        when(responder.NotFound()).thenReturn(ResponseEntity.notFound().build());

        // Calling the method to be tested
        ResponseEntity<APIResponse> response = stockService.getById(id);

        // Verifying the repository interactions
        verify(stockRepository, times(1)).findById(id);

        // Verifying the responder interactions
        verify(responder, times(1)).NotFound();

        // Asserting the response
        assert response.getStatusCode() == HttpStatus.NOT_FOUND;
    }

    @Test
    public void testUpdatePrice() {
        // Mocking the input data
        Long id = 1L;
        NewPriceDto newPriceDto = new NewPriceDto();
        newPriceDto.setPrice(150.0);

        // Mocking the repository
        // Mocking the responder behavior
        when(responder.Okay(any())).thenReturn(ResponseEntity.ok().build());

        // Calling the method to be tested
        ResponseEntity<APIResponse> response = stockService.updatePrice(id, newPriceDto);

        // Verifying the repository interactions
        verify(stockRepository, times(1)).findById(id);
        verify(stockRepository, times(1)).save(any());

        // Verifying the responder interactions
        verify(responder, times(1)).Okay(any());

        // Asserting the response
        assert response.getStatusCode() == HttpStatus.OK;
    }

    @Test
    public void testUpdatePriceNotFound() {
        // Mocking the input data
        Long id = 1L;
        NewPriceDto newPriceDto = new NewPriceDto();
        newPriceDto.setPrice(150.0);

        // Mocking the repository behavior
        when(stockRepository.findById(id)).thenReturn(Optional.empty());

        // Mocking the responder behavior
        when(responder.NotFound()).thenReturn(ResponseEntity.notFound().build());

        // Calling the method to be tested
        ResponseEntity<APIResponse> response = stockService.updatePrice(id, newPriceDto);

        // Verifying the repository interactions
        verify(stockRepository, times(1)).findById(id);

        // Verifying the responder interactions
        verify(responder, times(1)).NotFound();

        // Asserting the response
        assert response.getStatusCode() == HttpStatus.NOT_FOUND;
    }

    @Test
    public void testCreateStock() {
        // Mocking the input data
        NewStockDto newStockDto = new NewStockDto();
        newStockDto.setName("Test Stock");
        newStockDto.setCurrentPrice(100.0);
        newStockDto.setCreateDate(new Date());

        // Mocking the repository behavior
        when(stockRepository.save(any())).thenReturn(new Stock());

        // Mocking the responder behavior
        when(responder.Okay(any())).thenReturn(ResponseEntity.created(null).build());

        // Calling the method to be tested
        ResponseEntity<APIResponse> response = stockService.createStock(newStockDto);

        // Verifying the repository interactions
        verify(stockRepository, times(1)).save(any());

        // Verifying the responder interactions
        verify(responder, times(1)).Okay(any());

        // Asserting the response
        assert response.getStatusCode() == HttpStatus.CREATED;
    }



}
