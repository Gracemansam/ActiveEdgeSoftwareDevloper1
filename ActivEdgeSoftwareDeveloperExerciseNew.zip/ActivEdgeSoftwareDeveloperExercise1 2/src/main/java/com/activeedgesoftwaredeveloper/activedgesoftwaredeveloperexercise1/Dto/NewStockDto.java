package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewStockDto {
    private String name;
    private Double currentPrice;
    private Date createDate;
    private Date lastUpdate;
}
