package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "stocks")
@Builder
public class Stock {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private double currentPrice;
    @CreationTimestamp
    private Date createDate;
    private Date lastUpdate;


    public Stock(Long id,String stockName, double currentPrice, Date date) {
        this.id = id;
        this.name = stockName;
        this.currentPrice = currentPrice;
        this.createDate = date;
    }
    public Stock(String stockName, double currentPrice, Date date) {
        this.name = stockName;
        this.currentPrice = currentPrice;
        this.createDate = date;
    }
}


