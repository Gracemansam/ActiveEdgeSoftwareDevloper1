package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.controller;

import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto.NewPriceDto;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto.NewStockDto;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.model.Stock;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.service.StockService;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.utils.APIResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/stock")
@AllArgsConstructor
public class StockController {
    private final StockService stockService;


    @GetMapping("/getAllStock")
    public List<Stock> getAllStocks() {
        return stockService.getAllStock();
    }


    @GetMapping("/getById/{id}")
    public ResponseEntity<APIResponse> getStockById(@PathVariable Long id) {
        return stockService.getById(id);
    }

    @PutMapping("/{id}")
    public ResponseEntity<APIResponse> updateStockPrice(@PathVariable Long id, @RequestBody NewPriceDto newPrice) {
        return stockService.updatePrice(id,newPrice);
    }

    @PostMapping("/createStock")
    public ResponseEntity<APIResponse> createStock(@RequestBody NewStockDto newStock) {
       return stockService.createStock(newStock);
    }

}
