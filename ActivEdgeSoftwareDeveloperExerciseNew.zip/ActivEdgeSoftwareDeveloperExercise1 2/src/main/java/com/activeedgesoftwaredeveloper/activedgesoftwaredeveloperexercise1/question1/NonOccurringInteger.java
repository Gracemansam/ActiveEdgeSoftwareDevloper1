package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.question1;

    import java.util.Arrays;

    public class NonOccurringInteger {

        public static int gettingNonOccurringInteger(int[] arr) {
            // Sort the array in ascending order

            Arrays.sort(arr);

            // Start by assuming the smallest non-occurring integer is 1

            int smallestNonOccurringInt = 1;

            // Loop through the sorted array

            for (int i = 0; i < arr.length; i++) {
                // If the current number is less than or equal to the current smallestNonOccurringInt,
                // we need to increment the smallestNonOccurringInt to the next integer (arr[i] + 1)

                if (arr[i] <= smallestNonOccurringInt) {
                    smallestNonOccurringInt = arr[i] + 1;
                }
            }

            return smallestNonOccurringInt;
        }

        public static void main(String[] args) {
            int[] arr1 = {1, 3, 6, 4, 1, 2};
            System.out.println(gettingNonOccurringInteger(arr1));
            // Output: 5

            int[] arr2 = {5, -1, -3};
            System.out.println(gettingNonOccurringInteger(arr2));
            // Output: 1
        }
    }


