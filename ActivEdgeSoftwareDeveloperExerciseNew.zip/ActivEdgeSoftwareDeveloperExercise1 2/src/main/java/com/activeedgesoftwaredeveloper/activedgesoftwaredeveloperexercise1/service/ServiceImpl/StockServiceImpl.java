package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.service.ServiceImpl;

import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto.NewPriceDto;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto.NewStockDto;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Exception.StockNotFoundException;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.model.Stock;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.repository.StockRepository;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.service.StockService;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.utils.APIResponse;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.utils.Responder;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class StockServiceImpl implements StockService {

    private final StockRepository stockRepository;
    private final Responder responder;

    @Override
    public List<Stock> getAllStock() {
        return stockRepository.findAll();
    }

    @Override
    public ResponseEntity<APIResponse> getById(Long id) {
        Optional<Stock> findExistingStock = stockRepository.findById(id);
        if (findExistingStock.isPresent()) {
            return responder.Okay(findExistingStock.get());
        } else {
            return responder.NotFound();
        }
    }


    @Override
    public ResponseEntity<APIResponse> updatePrice(Long id, NewPriceDto newPrice) {
        Optional<Stock> stockOptional = stockRepository.findById(id);

        if (stockOptional.isPresent()) {
            Stock stock = stockOptional.get();
            stock.setCurrentPrice(newPrice.getPrice());
            stock.setLastUpdate(new Date());
            stockRepository.save(stock);
            return responder.Okay(stock);
        } else {
            throw new StockNotFoundException(id);
        }


    }

    @Override
    public ResponseEntity<APIResponse> createStock(NewStockDto newStockDto) {
        Optional<Stock> findStock = stockRepository.findByName(newStockDto.getName());

        if (findStock.isPresent()) {
            return responder.AlreadyExist("product already exist");
        } else {
            Stock newStock = Stock.builder()
                    .name(newStockDto.getName())
                    .currentPrice(newStockDto.getCurrentPrice())
                    .createDate(new Date())
                    .build();
            stockRepository.save(newStock);
            return responder.Okay(newStock);
        }

    }
}
