package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewPriceDto {
    private Double price;
}
