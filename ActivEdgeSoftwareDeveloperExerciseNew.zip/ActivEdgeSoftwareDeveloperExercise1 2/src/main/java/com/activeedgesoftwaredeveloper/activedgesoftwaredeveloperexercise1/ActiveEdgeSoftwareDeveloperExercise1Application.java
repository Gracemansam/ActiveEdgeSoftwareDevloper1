package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1;

import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.model.Stock;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.repository.StockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SpringBootApplication
public class ActiveEdgeSoftwareDeveloperExercise1Application implements CommandLineRunner {
   @Autowired
    private StockRepository stockRepository;


    public static void main(String[] args) {
        SpringApplication.run(ActiveEdgeSoftwareDeveloperExercise1Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // Delete all stock records from the database
        stockRepository.deleteAll();

        // Initialize the list of stocks on application startup
        Stock stock1 = new Stock("Stock A", 10.00, new Date());
        stockRepository.save(stock1);

        Stock stock2 = new Stock("Stock B", 20.00, new Date());
        stockRepository.save(stock2);
    }
}
