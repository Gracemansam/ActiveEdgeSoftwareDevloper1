package com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.service;

import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto.NewPriceDto;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.Dto.NewStockDto;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.model.Stock;
import com.activeedgesoftwaredeveloper.activedgesoftwaredeveloperexercise1.utils.APIResponse;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

public interface StockService {

    List<Stock> getAllStock();

    ResponseEntity<APIResponse> getById(Long Id);

    ResponseEntity<APIResponse> updatePrice(Long id, NewPriceDto newPrice);
    ResponseEntity<APIResponse> createStock(NewStockDto newStockDto);
}
